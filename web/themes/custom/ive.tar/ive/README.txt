ABOUT ive
------------

ive is the default theme for Drupal 8.  It is a flexible, recolorable theme
with a responsive and mobile-first layout, supporting 16 regions.

The ive theme is named after Jean ive, one of the original programmers
for the ENIAC computer.

This theme is not intended to be used as a base theme.

To read more about the ive theme please see:
https://www.drupal.org/docs/8/core/themes/ive-theme

ABOUT DRUPAL THEMING
--------------------

See https://www.drupal.org/docs/8/theming for more information on Drupal
theming.
