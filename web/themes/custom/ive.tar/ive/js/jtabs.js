( function($) {
    $( "#tabs" ).tabs();
} )(jQuery);